package funkin.ui.debug.stageeditor.components;

#if FEATURE_STAGE_EDITOR
import haxe.ui.containers.dialogs.Dialog;
import haxe.ui.containers.dialogs.Dialogs;
import haxe.ui.containers.dialogs.MessageBox.MessageBoxType;
import haxe.ui.components.Link;
import funkin.save.Save;
import funkin.util.FileUtil;
import flixel.FlxG;
import funkin.data.stage.StageData;
import funkin.data.stage.StageRegistry;
import funkin.ui.debug.stageeditor.StageEditorState.StageEditorDialogType;

@:build(haxe.ui.macros.ComponentMacros.build("assets/exclude/data/ui/stage-editor/dialogs/welcome.xml"))
class WelcomeDialog extends Dialog
{
  var stageEditorState:StageEditorState;

  override public function new(state:StageEditorState)
  {
    super();

    stageEditorState = state;

    buttonNew.onClick = function(_)
    {
      stageEditorState.clearAssets();
      stageEditorState.loadDummyData();
      stageEditorState.currentFile = "";
      killDaDialog();
    }

    for (file in Save.instance.stageEditorPreviousFiles.value)
    {
      trace(file);

      if (!FileUtil.fileExists(file)) continue; // whats the point of loading something that doesnt exist

      var patj = new haxe.io.Path(file);

      var fileText = new Link();
      fileText.percentWidth = 100;
      fileText.text = patj.file + "." + patj.ext;
      fileText.onClick = function(_)
      {
        fileText.hide();
        loadFromFilePath(file, null, 0, 0);
      };

      #if sys
      var stat = sys.FileSystem.stat(file);
      var sizeInMB = (stat.size / 1000000).round(3);

      fileText.tooltip = "Full Name: " + file + "\nLast Modified: " + stat.mtime.toString() + "\nSize: " + sizeInMB + " MB";
      #end

      contentRecent.addComponent(fileText);
    }

    boxDrag.onClick = function(_) FileUtil.browseForFile("Open Stage Data", [FileUtil.FILE_FILTER_FNFS],
      (fileInfo) -> loadFromFilePath(fileInfo.fullPath, null, 0, 0));

    var defaultStages:Array<String> = StageRegistry.instance.listEntryIds();
    defaultStages.sort(funkin.util.SortUtil.alphabetically);

    for (stage in defaultStages)
    {
      var baseStage = StageRegistry.instance.parseEntryDataWithMigration(stage, StageRegistry.instance.fetchEntryVersion(stage));
      if (baseStage == null) continue;

      var link = new Link(); // this is how the legend of zelda started btw
      link.percentWidth = 100;
      link.text = baseStage.name;

      link.onClick = function(_) loadFromPreset(baseStage);

      contentPresets.addComponent(link);
    }

    FlxG.stage.window.onDropFile.add(loadFromFilePath);
  }

  public function loadFromPreset(data:StageData)
  {
    if (data == null) return;

    if (!stageEditorState.saved)
    {
      Dialogs.messageBox("You will lose all of your unsaved work.\n\nAre you sure? This cannot be undone.", "Load Stage", MessageBoxType.TYPE_YESNO, true,
        function(btn:DialogButton)
        {
          if (btn == DialogButton.YES)
          {
            stageEditorState.saved = true;
            loadFromPreset(data);
          }
        });

      return;
    }

    stageEditorState.clearAssets();
    stageEditorState.currentFile = "";
    stageEditorState.loadFromDataRaw(data);
    killDaDialog();
  }

  public function loadFromFilePath(file:String, state:String, x:Float, y:Float)
  {
    if (!stageEditorState.saved)
    {
      Dialogs.messageBox("You will lose all of your unsaved work.\n\nAre you sure? This cannot be undone.", "Load Stage", MessageBoxType.TYPE_YESNO, true,
        function(btn:DialogButton)
        {
          if (btn == DialogButton.YES)
          {
            stageEditorState.saved = true;
            loadFromFilePath(file, state, x, y);
          }
        });

      return;
    }

    var bytes = FileUtil.readBytesFromPath(file);

    if (bytes == null)
    {
      stageEditorState.notifyChange("Problem Loading the Stage", "The Stage File could not be loaded.", true);
      return;
    }

    stageEditorState.clearAssets();
    stageEditorState.currentFile = file;
    stageEditorState.unpackShitFromZip(bytes);
    killDaDialog();
  }

  function killDaDialog()
  {
    stageEditorState.updateDialog(StageEditorDialogType.OBJECT_GRAPHIC);
    stageEditorState.updateDialog(StageEditorDialogType.OBJECT_PROPERTIES);
    stageEditorState.updateDialog(StageEditorDialogType.CHARACTER);
    stageEditorState.updateDialog(StageEditorDialogType.STAGE);

    FlxG.stage.window.onDropFile.remove(loadFromFilePath);
    hide();
    destroy();
  }
}
#end
