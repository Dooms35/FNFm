package funkin.ui.debug.stageeditor.components;

#if FEATURE_STAGE_EDITOR
import haxe.ui.containers.dialogs.Dialog;
import funkin.ui.debug.stageeditor.handlers.AssetDataHandler;
import funkin.ui.debug.stageeditor.StageEditorState.StageEditorAssetFile;
import openfl.display.BitmapData;
import haxe.io.Bytes;
import haxe.ui.notifications.NotificationType;
import haxe.ui.notifications.NotificationManager;

@:build(haxe.ui.macros.ComponentMacros.build('assets/exclude/data/ui/stage-editor/dialogs/new-object.xml'))
class NewObjDialog extends Dialog
{
  public var bitmapName:Null<String> = null;

  var stageEditorState:StageEditorState;
  var data:Bytes;

  override public function new(state:StageEditorState, data:Bytes = null)
  {
    super();

    stageEditorState = state;
    this.data = data;

    field.onChange = function(_)
    {
      field.removeClasses(['invalid-value', 'valid-value']);
    }

    buttons = DialogButton.CANCEL | '{{Create}}';
    defaultButton = '{{Create}}';

    destroyOnClose = true;
  }

  override public function validateDialog(button:DialogButton, fn:Bool->Void)
  {
    var done = true;

    if (button == '{{Create}}')
    {
      var objNames:Array<String> = [
        for (obj in stageEditorState.spriteArray) obj.name
      ];

      if (field.text == '' || field.text == null || objNames.contains(field.text))
      {
        field.swapClass('invalid-value', 'valid-value');
        done = false;
        NotificationManager.instance.addNotification({
          title: 'Problem Creating an Object',
          body: objNames.contains(field.text) ? 'Object with the Name ' + field.text + ' already exists!' : 'Invalid Object Name!',
          type: NotificationType.Error
        });
      }
      else
      {
        var spr = new StageEditorObject();

        if (data != null)
        {
          var file:StageEditorAssetFile = stageEditorState.createFile(bitmapName, data);
          spr.loadGraphic(BitmapData.fromBytes(file.data));

          spr.usedFiles.push(file);
        }
        else
          spr.loadGraphic(AssetDataHandler.getDefaultGraphic());

        spr.name = field.text;
        spr.screenCenter();

        var sprArray:Array<StageEditorObject> = stageEditorState.spriteArray;
        spr.zIndex = sprArray.length == 0 ? 0 : (sprArray[sprArray.length - 1].zIndex + 1);

        stageEditorState.selectedSprite = spr;
        stageEditorState.createAndPushAction(OBJECT_CREATED);

        stageEditorState.add(spr);
        stageEditorState.updateArray();
        stageEditorState.saved = false;

        NotificationManager.instance.addNotification({
          title: 'Object Creating Successful',
          body: 'Successfully created an Object with the Name ' + field.text + '!',
          type: NotificationType.Success
        });
      }
    }
    fn(done);
  }
}
#end
